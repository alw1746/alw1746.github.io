//*****************************************************************************

                // C Header File for TinyPort

//****************************************************************************

#ifdef __cplusplus
extern "C" {
#endif

DWORD WINAPI OpenTinyPort (PHANDLE THandle);
DWORD WINAPI CloseTinyPort (HANDLE THandle);
DWORD WINAPI WriteByte (HANDLE THandle, DWORD Address, BYTE Data);
DWORD WINAPI WriteWord (HANDLE THandle, DWORD Address, WORD Data);
DWORD WINAPI WriteDWord (HANDLE THandle, DWORD Address, DWORD Data);
DWORD WINAPI ReadByte (HANDLE THandle, DWORD Address, PBYTE Data);
DWORD WINAPI ReadWord (HANDLE THandle, DWORD Address, PWORD Data);
DWORD WINAPI ReadDWord (HANDLE THandle, DWORD Address, PDWORD Data);
DWORD WINAPI GetTinyPortVersion (HANDLE THandle, PDWORD Version);

#ifdef __cplusplus
}
#endif

//****************************************************************************

/*           Example for reading a byte from port 3e0:
.
.
DWORD   Res;
BYTE    AByte;
HANDLE  h;
.
.
Res = OpenTinyPort (&h);
if (Res != ERROR_SUCCESS) //..... error handling
.
.
Res = ReadByte (h, 0x3e0, &AByte);
if (Res != ERROR_SUCCESS) //..... error handling

printf ("Byte read: %x\n", AByte);

CloseTinyPort (h);
*/

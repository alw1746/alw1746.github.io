﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using UsbLibrary;

namespace UsbADC
{
  public partial class usbcapt : Form
  {
    bool started;
    Graphics graphics;
    Bitmap bmp;
    int PlotRate;
    int prev;
    Pen pen;

    public usbcapt()
    {
      InitializeComponent();
      started = false;
      bmp = new Bitmap(pictureBox1.Width, pictureBox1.Height);
      //graphics = this.pictureBox1.CreateGraphics();
      graphics = Graphics.FromImage(bmp);
      PlotRate = 1;
      prev = 0;
      pen = Pens.Red;
    }

    private void btn_ok_Click(object sender, EventArgs e)
    {
      try
      {
        if (!started)
        {
          usb.ProductId = int.Parse(this.tb_product.Text, System.Globalization.NumberStyles.HexNumber);
          usb.VendorId = int.Parse(this.tb_vendor.Text, System.Globalization.NumberStyles.HexNumber);
          usb.CheckDevicePresent();
          btn_ok.BackColor = Color.Crimson;
          btn_ok.Text = "Freeze";
          started = true;
          this.timer1.Enabled = true;
        }
        else
        {
          btn_ok.BackColor = Color.Lime;
          btn_ok.Text = "Start";
          started = false;
          this.timer1.Enabled = false;
        }
      }
      catch (Exception exception)
      {
        MessageBox.Show(exception.ToString());
      }
    }

    private void button1_Click(object sender, EventArgs e)
    {
      this.min1 = 0x270f;
      this.max1 = -1;
      this.min2 = 0x270f;
      this.max2 = -1;
      this.label_max1.Text = this.max1.ToString();
      this.label_min1.Text = this.min1.ToString();
    }

    protected override void OnHandleCreated(EventArgs e)
    {
      base.OnHandleCreated(e);
      usb.RegisterHandle(base.Handle);
    }

    private void timer1_Tick(object sender, EventArgs e)
    {
      int dif;
      this.timer1.Enabled = false;
      dif = smplcnt - prev;
      prev = smplcnt;
      this.toolStripStatusLabel1.Text = "Samples/sec " + dif.ToString();
      this.timer1.Enabled = true;
    }

    private void usb_OnDataReceived(object sender, DataReceivedEventArgs args)
    {
      if (base.InvokeRequired)
      {
        try
        {
          base.Invoke(new DataReceivedEventHandler(usb_OnDataReceived), new object[] { sender, args });
        }
        catch (Exception exception)
        {
          Console.WriteLine(exception.ToString());
        }
      }
      else
      {
        if (!started)
        {
          return;
        }
        float num = ((args.data[1] * 0x100) + args.data[2]) * 0.92f;
        float num2 = ((args.data[3] * 0x100) + args.data[4]) * 0.92f;
        int num3 = (int)num;
        int num4 = (int)num2;
        this.smplcnt++;
        /*
        if (this.checkBox2.Checked)
        {
          this.valbuf1[this.bufptr] = num;
          this.valbuf2[this.bufptr] = num2;
          this.bufptr++;
          if (this.bufptr > this.maxbuf)
          {
            this.bufptr = 0;
          }
          int index = 0;
          float num6 = 0f;
          for (index = 0; index < this.maxbuf; index++)
          {
            num6 += this.valbuf1[index];
          }
          num3 = (int)(num6 / ((float)this.maxbuf));
          num6 = 0f;
          for (index = 0; index < this.maxbuf; index++)
          {
            num6 += this.valbuf2[index];
          }
          num4 = (int)(num6 / ((float)this.maxbuf));
        }
         */
          if (num3 > this.max1)
          {
            this.max1 = num3;
            this.label_max1.Text = this.max1.ToString();
          }
          if (num3 < this.min1)
          {
            this.min1 = num3;
            this.label_min1.Text = this.min1.ToString();
          }
          if (num4 > this.max2)
          {
            this.max2 = num4;
            this.label_max2.Text = this.max2.ToString();
          }
          if (num4 < this.min2)
          {
            this.min2 = num4;
            this.label_min2.Text = this.min2.ToString();
          }
          if ((smplcnt % 100) == 0)
          {
            this.label1.Text = num3.ToString().Trim();
            this.label3.Text = num4.ToString().Trim();
          }
        if ((this.smplcnt % PlotRate) == 0)
        {
          //Graphics graphics = this.pictureBox1.CreateGraphics();

          float num7 = ((float)num3) / 2600f;
          float num8 = ((float)num4) / 2600f;
          num7 = (this.pictureBox1.Height - 10) * (1f - num7);
          num8 = (this.pictureBox1.Height - 10) * (1f - num8);
          graphics.DrawLine(Pens.Black, this.ti + 1, 0, this.ti + 1, this.pictureBox1.Height);
          graphics.DrawLine(Pens.BlueViolet, this.ti + 2, 0, this.ti + 2, this.pictureBox1.Height);
          graphics.DrawLine(pen, (float)this.ti, this.old_gval1, (float)(this.ti + 1), num7);
          graphics.DrawLine(Pens.Gold, (float)this.ti, this.old_gval2, (float)(this.ti + 1), num8);
          this.old_gval1 = num7;
          this.old_gval2 = num8;
          this.ti++;
          if (this.ti > this.pictureBox1.Width)
          {
            this.ti = 0;
            graphics.DrawLine(Pens.Black, 0, 0, 0, this.pictureBox1.Height);
            /*
            if (pen.Equals(Pens.Red))
              pen = Pens.White;
            else
              pen = Pens.Red;
             */
          }
          pictureBox1.Image = bmp;
          //graphics.Dispose();
        }
      }
    }

    private void usb_OnDeviceArrived(object sender, EventArgs e)
    {
      this.toolStripStatusLabel1.Text = "Found a Device";
    }

    private void usb_OnDeviceRemoved(object sender, EventArgs e)
    {
      if (base.InvokeRequired)
      {
        base.Invoke(new EventHandler(usb_OnDeviceRemoved), new object[] { sender, e });
      }
      else
      {
        this.toolStripStatusLabel1.Text = "Device was removed";
      }
    }

    private void usb_OnSpecifiedDeviceArrived(object sender, EventArgs e)
    {
      this.toolStripStatusLabel1.Text = "USB capture device found";
    }

    private void usb_OnSpecifiedDeviceRemoved(object sender, EventArgs e)
    {
      if (base.InvokeRequired)
      {
        base.Invoke(new EventHandler(usb_OnSpecifiedDeviceRemoved), new object[] { sender, e });
      }
      else
      {
        this.toolStripStatusLabel1.Text = "USB capture device removed";
      }
    }

    protected override void WndProc(ref Message m)
    {
      usb.ParseMessages(ref m);
      base.WndProc(ref m);
    }

    private void numericUpDown1_ValueChanged(object sender, EventArgs e)
    {
      PlotRate = Convert.ToInt32(numericUpDown1.Value);
    }

    private void button2_Click(object sender, EventArgs e)
    {
      button2.BackColor = Color.Crimson;
      FileStream fs = new FileStream("UsbScope.png", FileMode.Create, FileAccess.Write);
      pictureBox1.Image.Save(fs, System.Drawing.Imaging.ImageFormat.Png);
      fs.Close();
      fs = null;
      button2.BackColor = Color.Lime;
    }

  }
}

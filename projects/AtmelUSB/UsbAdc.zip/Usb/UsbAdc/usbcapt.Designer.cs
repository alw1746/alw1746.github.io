﻿namespace UsbADC
{
  partial class usbcapt
  {
    /// <summary>
    /// Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    /// Required method for Designer support - do not modify
    /// the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
      this.components = new System.ComponentModel.Container();
      this.lb_vendor = new System.Windows.Forms.Label();
      this.btn_ok = new System.Windows.Forms.Button();
      this.lb_product = new System.Windows.Forms.Label();
      this.tb_vendor = new System.Windows.Forms.TextBox();
      this.tb_product = new System.Windows.Forms.TextBox();
      this.gb_filter = new System.Windows.Forms.GroupBox();
      this.gb_details = new System.Windows.Forms.GroupBox();
      this.label1 = new System.Windows.Forms.Label();
      this.label4 = new System.Windows.Forms.Label();
      this.label3 = new System.Windows.Forms.Label();
      this.label2 = new System.Windows.Forms.Label();
      this.pictureBox1 = new System.Windows.Forms.PictureBox();
      this.usb = new UsbLibrary.UsbHidPort(this.components);
      this.statusStrip1 = new System.Windows.Forms.StatusStrip();
      this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
      this.timer1 = new System.Windows.Forms.Timer(this.components);
      this.groupBox1 = new System.Windows.Forms.GroupBox();
      this.label6 = new System.Windows.Forms.Label();
      this.label5 = new System.Windows.Forms.Label();
      this.button1 = new System.Windows.Forms.Button();
      this.label_max2 = new System.Windows.Forms.Label();
      this.label_min2 = new System.Windows.Forms.Label();
      this.label_max1 = new System.Windows.Forms.Label();
      this.label_min1 = new System.Windows.Forms.Label();
      this.groupBox2 = new System.Windows.Forms.GroupBox();
      this.button2 = new System.Windows.Forms.Button();
      this.label7 = new System.Windows.Forms.Label();
      this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
      this.gb_filter.SuspendLayout();
      this.gb_details.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
      this.statusStrip1.SuspendLayout();
      this.groupBox1.SuspendLayout();
      this.groupBox2.SuspendLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
      this.SuspendLayout();
      // 
      // lb_vendor
      // 
      this.lb_vendor.AutoSize = true;
      this.lb_vendor.Location = new System.Drawing.Point(9, 17);
      this.lb_vendor.Name = "lb_vendor";
      this.lb_vendor.Size = new System.Drawing.Size(25, 13);
      this.lb_vendor.TabIndex = 5;
      this.lb_vendor.Text = "VID";
      // 
      // btn_ok
      // 
      this.btn_ok.BackColor = System.Drawing.Color.Lime;
      this.btn_ok.ForeColor = System.Drawing.Color.Black;
      this.btn_ok.Location = new System.Drawing.Point(75, 14);
      this.btn_ok.Name = "btn_ok";
      this.btn_ok.Size = new System.Drawing.Size(49, 46);
      this.btn_ok.TabIndex = 7;
      this.btn_ok.Text = "Start";
      this.btn_ok.UseVisualStyleBackColor = false;
      this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
      // 
      // lb_product
      // 
      this.lb_product.AutoSize = true;
      this.lb_product.Location = new System.Drawing.Point(9, 41);
      this.lb_product.Name = "lb_product";
      this.lb_product.Size = new System.Drawing.Size(25, 13);
      this.lb_product.TabIndex = 6;
      this.lb_product.Text = "PID";
      // 
      // tb_vendor
      // 
      this.tb_vendor.Location = new System.Drawing.Point(37, 14);
      this.tb_vendor.Name = "tb_vendor";
      this.tb_vendor.Size = new System.Drawing.Size(32, 20);
      this.tb_vendor.TabIndex = 1;
      this.tb_vendor.Text = "4242";
      // 
      // tb_product
      // 
      this.tb_product.Location = new System.Drawing.Point(37, 38);
      this.tb_product.Name = "tb_product";
      this.tb_product.Size = new System.Drawing.Size(32, 20);
      this.tb_product.TabIndex = 2;
      this.tb_product.Text = "0002";
      // 
      // gb_filter
      // 
      this.gb_filter.BackColor = System.Drawing.Color.CornflowerBlue;
      this.gb_filter.Controls.Add(this.btn_ok);
      this.gb_filter.Controls.Add(this.lb_product);
      this.gb_filter.Controls.Add(this.lb_vendor);
      this.gb_filter.Controls.Add(this.tb_vendor);
      this.gb_filter.Controls.Add(this.tb_product);
      this.gb_filter.ForeColor = System.Drawing.Color.White;
      this.gb_filter.Location = new System.Drawing.Point(7, 2);
      this.gb_filter.Name = "gb_filter";
      this.gb_filter.Size = new System.Drawing.Size(132, 65);
      this.gb_filter.TabIndex = 5;
      this.gb_filter.TabStop = false;
      this.gb_filter.Text = "USB Device";
      // 
      // gb_details
      // 
      this.gb_details.BackColor = System.Drawing.Color.CornflowerBlue;
      this.gb_details.Controls.Add(this.label1);
      this.gb_details.Controls.Add(this.label4);
      this.gb_details.Controls.Add(this.label3);
      this.gb_details.Controls.Add(this.label2);
      this.gb_details.ForeColor = System.Drawing.Color.White;
      this.gb_details.Location = new System.Drawing.Point(7, 82);
      this.gb_details.Name = "gb_details";
      this.gb_details.Size = new System.Drawing.Size(500, 93);
      this.gb_details.TabIndex = 6;
      this.gb_details.TabStop = false;
      // 
      // label1
      // 
      this.label1.BackColor = System.Drawing.Color.Transparent;
      this.label1.Font = new System.Drawing.Font("Arial", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label1.ForeColor = System.Drawing.Color.Crimson;
      this.label1.Location = new System.Drawing.Point(6, 13);
      this.label1.Name = "label1";
      this.label1.Size = new System.Drawing.Size(217, 76);
      this.label1.TabIndex = 10;
      this.label1.Text = "0";
      this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label4
      // 
      this.label4.AutoSize = true;
      this.label4.BackColor = System.Drawing.Color.Transparent;
      this.label4.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label4.ForeColor = System.Drawing.Color.Gold;
      this.label4.Location = new System.Drawing.Point(463, 13);
      this.label4.Name = "label4";
      this.label4.Size = new System.Drawing.Size(37, 24);
      this.label4.TabIndex = 13;
      this.label4.Text = "mv";
      this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label3
      // 
      this.label3.BackColor = System.Drawing.Color.Transparent;
      this.label3.Font = new System.Drawing.Font("Arial", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label3.ForeColor = System.Drawing.Color.Gold;
      this.label3.Location = new System.Drawing.Point(271, 14);
      this.label3.Name = "label3";
      this.label3.Size = new System.Drawing.Size(193, 75);
      this.label3.TabIndex = 12;
      this.label3.Text = "0";
      this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label2
      // 
      this.label2.AutoSize = true;
      this.label2.BackColor = System.Drawing.Color.Transparent;
      this.label2.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label2.ForeColor = System.Drawing.Color.Red;
      this.label2.Location = new System.Drawing.Point(221, 14);
      this.label2.Name = "label2";
      this.label2.Size = new System.Drawing.Size(37, 24);
      this.label2.TabIndex = 11;
      this.label2.Text = "mv";
      this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // pictureBox1
      // 
      this.pictureBox1.BackColor = System.Drawing.Color.Black;
      this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
      this.pictureBox1.Location = new System.Drawing.Point(7, 194);
      this.pictureBox1.Name = "pictureBox1";
      this.pictureBox1.Size = new System.Drawing.Size(500, 206);
      this.pictureBox1.TabIndex = 9;
      this.pictureBox1.TabStop = false;
      // 
      // usb
      // 
      this.usb.ProductId = 81;
      this.usb.VendorId = 1105;
      this.usb.OnSpecifiedDeviceRemoved += new System.EventHandler(this.usb_OnSpecifiedDeviceRemoved);
      this.usb.OnDeviceArrived += new System.EventHandler(this.usb_OnDeviceArrived);
      this.usb.OnDeviceRemoved += new System.EventHandler(this.usb_OnDeviceRemoved);
      this.usb.OnDataReceived += new UsbLibrary.DataReceivedEventHandler(this.usb_OnDataReceived);
      this.usb.OnSpecifiedDeviceArrived += new System.EventHandler(this.usb_OnSpecifiedDeviceArrived);
      // 
      // statusStrip1
      // 
      this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1});
      this.statusStrip1.Location = new System.Drawing.Point(0, 417);
      this.statusStrip1.Name = "statusStrip1";
      this.statusStrip1.Size = new System.Drawing.Size(517, 22);
      this.statusStrip1.TabIndex = 7;
      this.statusStrip1.Text = "statusStrip1";
      // 
      // toolStripStatusLabel1
      // 
      this.toolStripStatusLabel1.BackColor = System.Drawing.Color.Transparent;
      this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
      this.toolStripStatusLabel1.Size = new System.Drawing.Size(35, 17);
      this.toolStripStatusLabel1.Text = "ready";
      // 
      // timer1
      // 
      this.timer1.Interval = 800;
      this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
      // 
      // groupBox1
      // 
      this.groupBox1.Controls.Add(this.label6);
      this.groupBox1.Controls.Add(this.label5);
      this.groupBox1.Controls.Add(this.button1);
      this.groupBox1.Controls.Add(this.label_max2);
      this.groupBox1.Controls.Add(this.label_min2);
      this.groupBox1.Controls.Add(this.label_max1);
      this.groupBox1.Controls.Add(this.label_min1);
      this.groupBox1.Location = new System.Drawing.Point(311, 2);
      this.groupBox1.Name = "groupBox1";
      this.groupBox1.Size = new System.Drawing.Size(194, 65);
      this.groupBox1.TabIndex = 8;
      this.groupBox1.TabStop = false;
      // 
      // label6
      // 
      this.label6.AutoSize = true;
      this.label6.ForeColor = System.Drawing.Color.White;
      this.label6.Location = new System.Drawing.Point(134, 0);
      this.label6.Name = "label6";
      this.label6.Size = new System.Drawing.Size(26, 13);
      this.label6.TabIndex = 17;
      this.label6.Text = "max";
      // 
      // label5
      // 
      this.label5.AutoSize = true;
      this.label5.ForeColor = System.Drawing.Color.White;
      this.label5.Location = new System.Drawing.Point(75, 0);
      this.label5.Name = "label5";
      this.label5.Size = new System.Drawing.Size(23, 13);
      this.label5.TabIndex = 16;
      this.label5.Text = "min";
      // 
      // button1
      // 
      this.button1.BackColor = System.Drawing.Color.Lime;
      this.button1.ForeColor = System.Drawing.Color.Black;
      this.button1.Location = new System.Drawing.Point(6, 14);
      this.button1.Name = "button1";
      this.button1.Size = new System.Drawing.Size(53, 44);
      this.button1.TabIndex = 8;
      this.button1.Text = "Reset";
      this.button1.UseVisualStyleBackColor = false;
      this.button1.Click += new System.EventHandler(this.button1_Click);
      // 
      // label_max2
      // 
      this.label_max2.AutoSize = true;
      this.label_max2.BackColor = System.Drawing.Color.Transparent;
      this.label_max2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label_max2.ForeColor = System.Drawing.Color.Gold;
      this.label_max2.Location = new System.Drawing.Point(133, 36);
      this.label_max2.Name = "label_max2";
      this.label_max2.Size = new System.Drawing.Size(21, 22);
      this.label_max2.TabIndex = 15;
      this.label_max2.Text = "0";
      this.label_max2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // label_min2
      // 
      this.label_min2.AutoSize = true;
      this.label_min2.BackColor = System.Drawing.Color.Transparent;
      this.label_min2.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label_min2.ForeColor = System.Drawing.Color.Gold;
      this.label_min2.Location = new System.Drawing.Point(74, 36);
      this.label_min2.Name = "label_min2";
      this.label_min2.Size = new System.Drawing.Size(21, 22);
      this.label_min2.TabIndex = 14;
      this.label_min2.Text = "0";
      this.label_min2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
      // 
      // label_max1
      // 
      this.label_max1.AutoSize = true;
      this.label_max1.BackColor = System.Drawing.Color.Transparent;
      this.label_max1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label_max1.ForeColor = System.Drawing.Color.Crimson;
      this.label_max1.Location = new System.Drawing.Point(133, 16);
      this.label_max1.Name = "label_max1";
      this.label_max1.Size = new System.Drawing.Size(21, 22);
      this.label_max1.TabIndex = 13;
      this.label_max1.Text = "0";
      this.label_max1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // label_min1
      // 
      this.label_min1.AutoSize = true;
      this.label_min1.BackColor = System.Drawing.Color.Transparent;
      this.label_min1.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.label_min1.ForeColor = System.Drawing.Color.Crimson;
      this.label_min1.Location = new System.Drawing.Point(74, 16);
      this.label_min1.Name = "label_min1";
      this.label_min1.Size = new System.Drawing.Size(21, 22);
      this.label_min1.TabIndex = 12;
      this.label_min1.Text = "0";
      this.label_min1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
      // 
      // groupBox2
      // 
      this.groupBox2.Controls.Add(this.button2);
      this.groupBox2.Controls.Add(this.label7);
      this.groupBox2.Controls.Add(this.numericUpDown1);
      this.groupBox2.Location = new System.Drawing.Point(155, 2);
      this.groupBox2.Name = "groupBox2";
      this.groupBox2.Size = new System.Drawing.Size(140, 65);
      this.groupBox2.TabIndex = 9;
      this.groupBox2.TabStop = false;
      // 
      // button2
      // 
      this.button2.BackColor = System.Drawing.Color.Lime;
      this.button2.Location = new System.Drawing.Point(77, 14);
      this.button2.Name = "button2";
      this.button2.Size = new System.Drawing.Size(52, 45);
      this.button2.TabIndex = 3;
      this.button2.Text = "Snap";
      this.button2.UseVisualStyleBackColor = false;
      this.button2.Click += new System.EventHandler(this.button2_Click);
      // 
      // label7
      // 
      this.label7.AutoSize = true;
      this.label7.ForeColor = System.Drawing.Color.White;
      this.label7.Location = new System.Drawing.Point(15, 17);
      this.label7.Name = "label7";
      this.label7.Size = new System.Drawing.Size(63, 13);
      this.label7.TabIndex = 2;
      this.label7.Text = "Plot Sample";
      // 
      // numericUpDown1
      // 
      this.numericUpDown1.Location = new System.Drawing.Point(18, 34);
      this.numericUpDown1.Maximum = new decimal(new int[] {
            10,
            0,
            0,
            0});
      this.numericUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.numericUpDown1.Name = "numericUpDown1";
      this.numericUpDown1.Size = new System.Drawing.Size(49, 20);
      this.numericUpDown1.TabIndex = 1;
      this.numericUpDown1.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
      this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
      // 
      // usbcapt
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.CornflowerBlue;
      this.ClientSize = new System.Drawing.Size(517, 439);
      this.Controls.Add(this.pictureBox1);
      this.Controls.Add(this.groupBox2);
      this.Controls.Add(this.groupBox1);
      this.Controls.Add(this.statusStrip1);
      this.Controls.Add(this.gb_filter);
      this.Controls.Add(this.gb_details);
      this.DoubleBuffered = true;
      this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
      this.MaximizeBox = false;
      this.Name = "usbcapt";
      this.Text = "DIY 2 Channel Scope";
      this.gb_filter.ResumeLayout(false);
      this.gb_filter.PerformLayout();
      this.gb_details.ResumeLayout(false);
      this.gb_details.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
      this.statusStrip1.ResumeLayout(false);
      this.statusStrip1.PerformLayout();
      this.groupBox1.ResumeLayout(false);
      this.groupBox1.PerformLayout();
      this.groupBox2.ResumeLayout(false);
      this.groupBox2.PerformLayout();
      ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
      this.ResumeLayout(false);
      this.PerformLayout();

    }

    #endregion

    private System.Windows.Forms.Button btn_ok;
    private System.Windows.Forms.Button button1;
    private System.Windows.Forms.GroupBox gb_details;
    private System.Windows.Forms.GroupBox gb_filter;
    private System.Windows.Forms.GroupBox groupBox1;
    private System.Windows.Forms.GroupBox groupBox2;
    private System.Windows.Forms.Label label_max1;
    private System.Windows.Forms.Label label_max2;
    private System.Windows.Forms.Label label_min1;
    private System.Windows.Forms.Label label_min2;
    private System.Windows.Forms.Label label1;
    private System.Windows.Forms.Label label2;
    private System.Windows.Forms.Label label3;
    private System.Windows.Forms.Label label4;
    private System.Windows.Forms.Label label5;
    private System.Windows.Forms.Label label6;
    private System.Windows.Forms.Label lb_product;
    private System.Windows.Forms.Label lb_vendor;
    private int max1 = -1;
    private int max2 = -1;
    private int min1 = 0x270f;
    private int min2 = 0x270f;
    private float old_gval1;
    private float old_gval2;
    private System.Windows.Forms.PictureBox pictureBox1;
    private int smplcnt;
    private System.Windows.Forms.StatusStrip statusStrip1;
    private System.Windows.Forms.TextBox tb_product;
    private System.Windows.Forms.TextBox tb_vendor;
    private int ti;
    private System.Windows.Forms.Timer timer1;
    private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
    private float[] valbuf1 = new float[0x80];
    private float[] valbuf2 = new float[0x80];
    private UsbLibrary.UsbHidPort usb;
    private System.Windows.Forms.Label label7;
    private System.Windows.Forms.NumericUpDown numericUpDown1;
    private System.Windows.Forms.Button button2;

  }
}

